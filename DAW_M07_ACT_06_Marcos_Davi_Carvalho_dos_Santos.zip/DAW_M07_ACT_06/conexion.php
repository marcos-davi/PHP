<?php
//DAW_M07_ACT_06_Marcos_Davi_Carvalho_dos_Santos
	$host = "localhost";
	$user = "root";
	$password = "root";
	$db_name = "google_maps";
?>